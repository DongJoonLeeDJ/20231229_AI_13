package com.javalec.ex.dto;

import java.sql.Timestamp;

public class FDtoBuy {
private int buyid;
private String buyer;
private int foodid;
private String foodname;
private int buyprice;
private int buycount;
private String foodimage;
private Timestamp buydate;
private String deliveryAddress;
public int getBuyid() {
	return buyid;
}
public void setBuyid(int buyid) {
	this.buyid = buyid;
}
public String getBuyer() {
	return buyer;
}
public void setBuyer(String buyer) {
	this.buyer = buyer;
}
public int getFoodid() {
	return foodid;
}
public void setFoodid(int foodid) {
	this.foodid = foodid;
}
public String getFoodname() {
	return foodname;
}
public void setFoodname(String foodname) {
	this.foodname = foodname;
}
public int getBuyprice() {
	return buyprice;
}
public void setBuyprice(int buyprice) {
	this.buyprice = buyprice;
}
public int getBuycount() {
	return buycount;
}
public void setBuycount(int buycount) {
	this.buycount = buycount;
}
public String getFoodimage() {
	return foodimage;
}
public void setFoodimage(String foodimage) {
	this.foodimage = foodimage;
}
public Timestamp getBuydate() {
	return buydate;
}
public void setBuydate(Timestamp buydate) {
	this.buydate = buydate;
}
public String getDeliveryAddress() {
	return deliveryAddress;
}
public void setDeliveryAddress(String deliveryAddress) {
	this.deliveryAddress = deliveryAddress;
}
public FDtoBuy(int buyid, String buyer, int foodid, String foodname, int buyprice, int buycount, String foodimage,
		Timestamp buydate, String deliveryAddress) {
	this.buyid = buyid;
	this.buyer = buyer;
	this.foodid = foodid;
	this.foodname = foodname;
	this.buyprice = buyprice;
	this.buycount = buycount;
	this.foodimage = foodimage;
	this.buydate = buydate;
	this.deliveryAddress = deliveryAddress;
}
}
