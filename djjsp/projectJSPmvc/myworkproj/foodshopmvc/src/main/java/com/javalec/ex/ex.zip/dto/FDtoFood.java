package com.javalec.ex.dto;

public class FDtoFood {
private int foodid;

private String foodkind;
private String foodname;
private int foodprice;
private int foodcount;
private String foodimage;
public int getFoodid() {
	return foodid;
}
public void setFoodid(int foodid) {
	this.foodid = foodid;
}public String getFoodkind() {
	return foodkind;
}
public void setFoodkind(String foodkind) {
	this.foodkind = foodkind;
}
public String getFoodname() {
	return foodname;
}
public void setFoodname(String foodname) {
	this.foodname = foodname;
}
public int getFoodprice() {
	return foodprice;
}
public void setFoodprice(int foodprice) {
	this.foodprice = foodprice;
}
public int getFoodcount() {
	return foodcount;
}
public void setFoodcount(int foodcount) {
	this.foodcount = foodcount;
}
public String getFoodimage() {
	return foodimage;
}
public void setFoodimage(String foodimage) {
	this.foodimage = foodimage;
}
public FDtoFood(int foodid, String foodkind, String foodname, int foodprice, int foodcount, String foodimage) {
	this.foodid = foodid;
	this.foodkind= foodkind;
	this.foodname = foodname;
	this.foodprice = foodprice;
	this.foodcount = foodcount;
	this.foodimage = foodimage;
}
}
