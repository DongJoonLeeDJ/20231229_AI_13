package com.javalec.ex.dto;

public class FDtoManager {
private String managerid;
private String managerpasswd;
public String getManagerid() {
	return managerid;
}
public void setManagerid(String managerid) {
	this.managerid = managerid;
}
public String getManagerpasswd() {
	return managerpasswd;
}
public void setManagerpasswd(String managerpasswd) {
	this.managerpasswd = managerpasswd;
}
public FDtoManager(String managerid, String managerpasswd) {
	this.managerid = managerid;
	this.managerpasswd = managerpasswd;
}
}
