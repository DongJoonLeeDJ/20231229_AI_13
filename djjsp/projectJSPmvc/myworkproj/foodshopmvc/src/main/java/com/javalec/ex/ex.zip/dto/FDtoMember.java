package com.javalec.ex.dto;

public class FDtoMember {
private String iD;
private String passwD;
private String namE;
private String emaiL;
private String addresS;
private String teL;
public String getID() {
	return iD;
}
public void setID(String iD) {
	this.iD = iD;
}
public String getPasswD() {
	return passwD;
}
public void setPasswD(String passwD) {
	this.passwD = passwD;
}
public String getNamE() {
	return namE;
}
public void setNamE(String namE) {
	this.namE = namE;
}
public String getEmaiL() {
	return emaiL;
}

public void setEmaiL(String emaiL) {
	this.emaiL = emaiL;
}
public String getAddresS() {
	return addresS;
}
public void setAddresS(String addresS) {
	this.addresS = addresS;
}
public String getTeL() {
	return teL;
}
public void setTeL(String teL) {
	this.teL = teL;
}
public FDtoMember(String iD, String passwD, String namE, String emaiL, String addresS, String teL) {
	this.iD = iD;
	this.passwD = passwD;
	this.namE = namE;
	this.emaiL = emaiL;
	this.addresS = addresS;
	this.teL = teL;
}
}
