package com.javalec.ex.dto;

public class FDtoCart {
private int cartid;
private String buyer;

private int foodid;
private String foodname;
private int buyprice;
private int buycount;
private String foodimage;
public int getCartid() {
	return cartid;
}
public void setCartid(int cartid) {
	this.cartid = cartid;
}public String getBuyer() {
	return buyer;
}
public void setBuyer(String buyer) {
	this.buyer = buyer;
}
public int getFoodid() {
	return foodid;
}
public void setFoodid(int foodid) {
	this.foodid = foodid;
}
public String getFoodname() {
	return foodname;
}
public void setFoodname(String foodname) {
	this.foodname = foodname;
}
public int getBuyprice() {
	return buyprice;
}
public void setBuyprice(int buyprice) {
	this.buyprice = buyprice;
}
public int getBuycount() {
	return buycount;
}
public void setBuycount(int buycount) {
	this.buycount = buycount;
}
public String getFoodimage() {
	return foodimage;
}
public void setFoodimage(String foodimage) {
	this.foodimage = foodimage;
}
public FDtoCart(int cartid,String buyer, int foodid, String foodname, int buyprice, int buycount, String foodimage) {
	this.cartid = cartid;
	this.buyer = buyer;
	this.foodid = foodid;
	this.foodname = foodname;
	this.buyprice = buyprice;
	this.buycount = buycount;
	this.foodimage = foodimage;
}
}
