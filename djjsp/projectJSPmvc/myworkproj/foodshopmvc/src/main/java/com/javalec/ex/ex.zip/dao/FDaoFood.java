package com.javalec.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.javalec.ex.dto.FDtoFood;



public class FDaoFood {
	private DataSource ds;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	//생성자 호출하게 되면 DB커넥션이 생성됨
	public FDaoFood() {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	//음식 입력
	public void insertfood(int foodid, String foodkind, String foodname, int foodprice, int foodcount, String foodimage) {
		// TODO Auto-generated method stub
		try { 
			conn = ds.getConnection();
			String sql = 
			"insert into food values (?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,foodid);//Integer.parseInt(foodid)
			pstmt.setString(2,foodkind);
			pstmt.setString(3,foodname);
			pstmt.setInt(4, foodprice);
			pstmt.setInt(5, foodcount);
			pstmt.setString(6,foodimage);
			pstmt.executeUpdate();
		}  catch (Exception e) {
			// TODO: handle exception 
		} finally { 
			try { 
				pstmt.close(); 
				conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	//음식 삭제
	public void deletefood(int foodid)
	{
		try {
			conn = ds.getConnection();
			String sql = "delete from food where foodId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, foodid);
			pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	//음식 수정
	public void updatefood(int foodid, String foodkind, String foodname, int foodprice, int foodcount, String foodimage) {
		// TODO Auto-generated method stub
		try {
			conn = ds.getConnection();
			String sql = "update food set food_kind=? food_name=? food_price=? food_count=? food_image=? where food_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,foodkind);
			pstmt.setString(2,foodname);
			pstmt.setInt(3, foodprice);
			pstmt.setInt(4, foodcount);
			pstmt.setString(5,foodimage);
			pstmt.setInt(6, foodid);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				pstmt.close();
				conn.close(); 
			} catch (Exception e2) { 
				// TODO: handle exception
			}
		}
	}
	// foodId에 해당하는 음식의 정보를 얻어내는 메소드로 등록된 음식을 수정하기 위해 수정폼으로 읽어들기이기 위한 메소드
	public FDtoFood getFood(int foodId)
		    throws Exception {
		FDtoFood food = null;
		 try {
       	 
			 conn=ds.getConnection();
            pstmt = conn.prepareStatement(
          	     "select * from member where id = ?");
            pstmt.setInt(1, foodId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
          
          int foodid= (rs.getInt("food_id"));
          String foodkind= (rs.getString("food_kind"));
          String foodname = (rs.getString("food_name"));
          int foodprice = (rs.getInt("food_price"));
          int foodcount = (rs.getInt("food_count"));
          String foodimage = (rs.getString("food_image"));
          food = new FDtoFood(foodid,foodkind,foodname,foodprice,foodcount,foodimage);
			 }
        }catch(Exception e) {
            
        }finally {try {
       	 rs.close();
			 pstmt.close();	 
        conn.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
        
      
	}return food;}
		    
	// 쇼핑몰 메인에 표시하기 위해서 사용하는 분류별 음식목록을 얻어내는 메소드
	public FDtoFood[] getFoods(String food_kind,int count)
		    throws Exception {
		        FDtoFood food = null;
		        FDtoFood foodList[]=null;
		        
		        int i=0;
		        
		        try {
		            
		        	conn=ds.getConnection();
		            String sql = "select * from food where food_kind=?";
		            sql += "order by food_id desc limit ?,?";
		            
		            pstmt = conn.prepareStatement(sql);
		            pstmt.setString(1, food_kind);
		            pstmt.setInt(2, 0);
		            pstmt.setInt(3, count);
		        	rs = pstmt.executeQuery();

		            if (rs.next()) {
		                foodList = new FDtoFood[count];
		                do{
		                	
		                     int foodid= rs.getInt("food_id");
		                     String foodkind = (rs.getString("food_kind"));
		                    String foodname = (rs.getString("food_name"));
		                     int foodprice = (rs.getInt("food_price"));
		                     int foodcount = (rs.getShort("food_count"));
		                    String foodimage = (rs.getString("food_image"));
		                     food = new FDtoFood(foodid,foodkind,foodname,foodprice,foodcount,foodimage);
		                     foodList[i]=food;
		                     
		                     i++;
					    }while(rs.next());
					}
		        } catch(Exception ex) {
		            ex.printStackTrace();
		        } finally {
		            if (rs != null) 
		            	try { rs.close(); } catch(SQLException ex) {}
		            if (pstmt != null) 
		            	try { pstmt.close(); } catch(SQLException ex) {}
		            if (conn != null) 
		            	try { conn.close(); } catch(SQLException ex) {}
		        }
				return foodList;
		    }
	// 분류별또는 전체등록된 음식의 정보를 얻어내는 메소드
	public List<FDtoFood> getFoods(String food_kind)
		    throws Exception {
		       FDtoFood food = null;
		        List<FDtoFood> foodList=null;
		        
		        try {
		           
		        	conn=ds.getConnection();
		            String sql1 = "select * from food";
		            String sql2 = "select * from food ";
		            sql2 += "where food_kind  = ? order by food_id desc";
		            
		            if(food_kind.equals("all")){
		            	 pstmt = conn.prepareStatement(sql1);
		            }else{
		                pstmt = conn.prepareStatement(sql2);
		                pstmt.setString(1, food_kind);
		            }
		        	rs = pstmt.executeQuery();
		            
		            if (rs.next()) {
		                foodList = new ArrayList<FDtoFood>();
		                do{
		                    
		                     int foodid = rs.getInt("food_id");
		                     String foodkind= rs.getString("food_kind");
		                     String foodname =rs.getString("food_name");
		                     int foodprice = rs.getInt("food_price");
		                     int foodcount = rs.getShort("food_count");
		                     String foodimage= rs.getString("food_image");
		                     food = new FDtoFood (foodid,foodkind,foodname,foodprice,foodcount,foodimage);
		                     foodList.add(food);
					    }while(rs.next());
					}
		        } catch(Exception ex) {
		            ex.printStackTrace();
		        } finally {
		            if (rs != null) 
		            	try { rs.close(); } catch(SQLException ex) {}
		            if (pstmt != null) 
		            	try { pstmt.close(); } catch(SQLException ex) {}
		            if (conn != null) 
		            	try { conn.close(); } catch(SQLException ex) {}
		        }
				return foodList;
		    }
	// 전체등록된 음식의 수를 얻어내는 메소드
	public int getFoodCount()
	{
		     
		        int x=0;

		        try {
		        	conn=ds.getConnection();
		            
		            pstmt = conn.prepareStatement("select count(*) from food");
		            rs = pstmt.executeQuery();

		            if (rs.next()) 
		               x= rs.getInt(1);
		        } catch(Exception ex) {
		            ex.printStackTrace();
		        } finally {
		            if (rs != null) 
		            	try { rs.close(); } catch(SQLException ex) {}
		            if (pstmt != null) 
		            	try { pstmt.close(); } catch(SQLException ex) {}
		            if (conn != null) 
		            	try { conn.close(); } catch(SQLException ex) {}
		        }
				return x;
		    }
	
}
